"use strict";
var RestaurantSimulation;
(function (RestaurantSimulation) {
    class Item {
        name;
        constructor(name) {
            this.name = name;
        }
    }
    RestaurantSimulation.Item = Item;
})(RestaurantSimulation || (RestaurantSimulation = {}));
//# sourceMappingURL=Item.js.map