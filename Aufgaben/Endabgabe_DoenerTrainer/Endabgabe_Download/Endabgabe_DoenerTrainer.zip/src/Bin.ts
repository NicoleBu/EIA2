namespace RestaurantSimulation{
    export class Bin extends Entity{
        constructor( pos: Vector) {
            super(pos);
        }
    }
}