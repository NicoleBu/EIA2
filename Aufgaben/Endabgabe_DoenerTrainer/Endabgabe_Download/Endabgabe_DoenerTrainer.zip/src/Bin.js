"use strict";
var RestaurantSimulation;
(function (RestaurantSimulation) {
    class Bin extends RestaurantSimulation.Entity {
        constructor(pos) {
            super(pos);
        }
    }
    RestaurantSimulation.Bin = Bin;
})(RestaurantSimulation || (RestaurantSimulation = {}));
//# sourceMappingURL=Bin.js.map